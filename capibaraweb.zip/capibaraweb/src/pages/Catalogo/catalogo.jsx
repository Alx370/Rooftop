const Catalogo = () => {
  return <h1 className="text-2xl font-semibold"> Catalogo Immobili</h1>;
};

export default Catalogo;
