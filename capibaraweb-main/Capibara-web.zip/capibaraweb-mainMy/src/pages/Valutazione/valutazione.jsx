const Valutazione = () => {
  return <h1 className="text-2xl font-semibold"> Valuta</h1>;
};

export default Valutazione;
