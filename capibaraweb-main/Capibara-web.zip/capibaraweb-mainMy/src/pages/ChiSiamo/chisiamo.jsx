const ChiSiamo = () => {
  return <h1 className="text-2xl font-semibold"> Chi Siamo</h1>;
};

export default ChiSiamo;
