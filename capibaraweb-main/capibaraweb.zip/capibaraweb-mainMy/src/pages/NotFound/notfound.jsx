const NotFound = () => {
  return <h1 className="text-2xl font-semibold text-red-600">404 - Pagina non trovata</h1>;
};

export default NotFound;
