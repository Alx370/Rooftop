const Agenti = () => {
  return <h1 className="text-2xl font-semibold"> I Nostri Agenti</h1>;
};

export default Agenti;
