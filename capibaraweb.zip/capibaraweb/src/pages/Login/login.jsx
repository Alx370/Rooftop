const Login = () => {
  return <h1 className="text-2xl font-semibold"> Login</h1>;
};

export default Login;
