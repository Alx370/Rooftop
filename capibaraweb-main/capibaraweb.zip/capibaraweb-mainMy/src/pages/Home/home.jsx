const Home = () => {
  return <h1 className="text-2xl font-semibold"> Home Page</h1>;
};

export default Home;
