import { BrowserRouter, Routes, Route } from "react-router-dom";
import Header from "../components/Header/Header.js";
import Footer from "../components/Footer/Footer.js";

import Home from "../pages/Home/home.jsx";
import Catalogo from "../pages/Catalogo/catalogo.jsx";
import Login from "../pages/Login/login.jsx";
import ChiSiamo from "../pages/ChiSiamo/chisiamo.jsx";
import Agenti from "../pages/Agenti/agenti.jsx";
import NotFound from "../pages/NotFound/notfound.jsx";

const AppRoutes = () => {
  return (
    <BrowserRouter>
      <Header />
      <main style={{ paddingTop: "80px", padding: "20px", minHeight: "80vh" }}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/catalogo" element={<Catalogo />} />
          <Route path="/chi-siamo" element={<ChiSiamo />} />
          <Route path="/agenti" element={<Agenti />} />
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
    </BrowserRouter>
  );
};

export default AppRoutes;