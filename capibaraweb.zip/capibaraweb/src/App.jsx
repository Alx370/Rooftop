import AppRoutes from "./routes/AppRoutes";
import "./index.css";

function App() {
  return <AppRoutes />;
}

export default App;
