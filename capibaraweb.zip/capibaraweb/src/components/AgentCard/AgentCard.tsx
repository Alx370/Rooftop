import React, { FC } from 'react';

interface AgentCardProps {}

const AgentCard: FC<AgentCardProps> = () => (

);

export default AgentCard;
