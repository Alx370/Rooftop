import React, { FC } from 'react';
import { PropertyCardWrapper } from './PropertyCard.styled';

interface PropertyCardProps {}

const PropertyCard: FC<PropertyCardProps> = () => (
 <PropertyCardWrapper>
    PropertyCard Component
 </PropertyCardWrapper>
);

export default PropertyCard;
